import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import { google } from "googleapis";
import fs from "fs";

// Load service account credentials
const CREDENTIALS = JSON.parse(fs.readFileSync("service-account.json"));

const app = express();
app.use(cors());
app.use(bodyParser.json());

const SCOPES = ["https://www.googleapis.com/auth/calendar"];
const calendarId = "communications@yourdomain.com"; // Replace with your calendar ID

const auth = new google.auth.JWT(
  CREDENTIALS.client_email,
  null,
  CREDENTIALS.private_key,
  SCOPES
);

const calendar = google.calendar({ version: "v3", auth });

app.post("/book", async (req, res) => {
  try {
    const { summary, description, start, end } = req.body;

    const event = {
      summary,
      description,
      start: {
        dateTime: start,
        timeZone: "America/New_York",
      },
      end: {
        dateTime: end,
        timeZone: "America/New_York",
      },
    };

    const response = await calendar.events.insert({
      calendarId,
      resource: event,
    });

    res.status(200).json({
      message: "Event created successfully",
      eventLink: response.data.htmlLink,
    });
  } catch (error) {
    console.error("Error creating event:", error);
    res.status(500).json({ error: error.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`📅 Calendar Booker running on port ${PORT}`));
